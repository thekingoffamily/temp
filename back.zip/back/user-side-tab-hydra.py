import logging
from flask import (
    Flask,
    jsonify,
    request,
    render_template,
    send_from_directory,
    abort
)
from flask_cors import CORS
import psycopg2
import requests
import cx_Oracle
from datetime import (
    datetime,
    timedelta
)
import os
import json
from functools import wraps
import ipaddress
import ssl


ALLOWED_IPS = [
    '10.57.14.15',
    '10.10.0.0/16'
]

def ip_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        client_ip = ipaddress.ip_address(request.remote_addr)
        if not any(client_ip in ipaddress.ip_network(ip) for ip in ALLOWED_IPS):
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
CORS(app)
# Oracle
oracle_data_user = 'AIS_RPC'
oracle_data_pass = '3ezDgiOjEZk7wp3AZ3PAuf2c'
oracle_data_dsn = '10.101.2.1/hydra'
# Postgresql
DB_HOST = "194.247.191.135"
DB_PORT = "5433"
DB_NAME = "proxima1c"
DB_USER = "proxima"
DB_PASS = "api"
# Подключение к БД
def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS
    )
# Получить строку пример 20240505112211 ГОДмесяцДЕНЬЧАСЫминутыСЕКУНДЫ
def get_date_time_for_id_payment():
    now = datetime.now()
    formatted_time = now.strftime("%Y%m%d%H%M%S")
    return str(formatted_time)

# Преобразовать строку даты в формат ГОДмесяцДЕНЬЧАСЫминутыСЕКУНДЫ
def convert_date_to_id_format(date_str):
    # Убираем время, если оно присутствует
    date_only_str = date_str.split(' ')[0]
    # Преобразуем строку в объект datetime
    date_obj = datetime.strptime(date_only_str, "%Y-%m-%d")
    # Форматируем дату в нужный формат с нулями для времени
    formatted_time = date_obj.strftime("%Y%m%d000000")
    return formatted_time

# Проксима пополнить счет
def payment_proxima(client: str, summ: int, comment: str, p_date: str) -> bool:
    params = {
        "command": "pay",
        "txn_id": get_date_time_for_id_payment(),
        "txn_date": get_date_time_for_id_payment() if not p_date else convert_date_to_id_format(p_date),
        "bank_code": "1c-proxima",
        "account": str(client),
        "sum": summ,
        "comment": str(comment)
    }
    # Формируем URL без кодирования comment
    url = f"https://10.101.2.4:9444/hydra/1c/main?command={params['command']}&txn_id={params['txn_id']}&txn_date={params['txn_date']}&bank_code={params['bank_code']}&account={params['account']}&sum={params['sum']}&comment={params['comment']}"
    print(f"URL для Proxima: {url}")  # Добавляем отладочное сообщение

    try:
        with requests.Session() as session:
            response = session.get(url, verify=False)  # Отключаем проверку сертификата SSL
            print(f"Ответ от Proxima: {response.status_code} - {response.text}")  # Добавляем отладочное сообщение
            status_payment = False
            if response.status_code == 200:
                status_payment = True
            return status_payment
    except requests.exceptions.RequestException as e:
        print(f"Ошибка при отправке запроса в Proxima: {e}")
        return False
    except Exception as e:
        print(f"Неизвестная ошибка: {e}")
        return False

# Проксимаком пополнить счет
def payment_prk(client: str, summ: int, comment: str, p_date: str) -> bool:
    params = {
        "command": "pay",
        "txn_id": get_date_time_for_id_payment(),
        "txn_date": get_date_time_for_id_payment() if not p_date else convert_date_to_id_format(p_date),
        "bank_code": "1c-proximacom",
        "account": str(client),
        "sum": summ,
        "comment": str(comment.replace(" ", "%20"))  # Экранируем пробелы в comment
    }
    # Формируем URL без кодирования comment
    url = f"https://10.101.2.4:9447/hydra/1c/main?command={params['command']}&txn_id={params['txn_id']}&txn_date={params['txn_date']}&bank_code={params['bank_code']}&account={params['account']}&sum={params['sum']}&comment={params['comment']}"
    print(f"URL для PRK: {url}")  # Добавляем отладочное сообщение

    try:
        with requests.Session() as session:
            response = session.get(url, verify=False)  # Отключаем проверку сертификата SSL
            print(f"Ответ от PRK: {response.status_code} - {response.text}")  # Добавляем отладочное сообщение
            status_payment = False
            if response.status_code == 200:
                status_payment = True
            return status_payment
    except requests.exceptions.RequestException as e:
        print(f"Ошибка при отправке запроса в PRK: {e}")
        return False
    except Exception as e:
        print(f"Неизвестная ошибка: {e}")
        return False

# Файбербидж пополнить счет
def payment_svd(client: str, summ: int, comment: str, p_date: str) -> bool:
    params = {
        "command": "pay",
        "txn_id": get_date_time_for_id_payment(),
        "txn_date": get_date_time_for_id_payment() if not p_date else convert_date_to_id_format(p_date),
        "bank_code": "1c-fb",
        "account": str(client),
        "sum": summ,
        "comment": str(comment.replace(" ", "%20"))  # Экранируем пробелы в comment
    }
    # Формируем URL без кодирования comment
    url = f"https://10.101.2.4:9443/hydra/1c/main?command={params['command']}&txn_id={params['txn_id']}&txn_date={params['txn_date']}&bank_code={params['bank_code']}&account={params['account']}&sum={params['sum']}&comment={params['comment']}"
    print(f"URL для SVD: {url}")  # Добавляем отладочное сообщение

    try:
        with requests.Session() as session:
            response = session.get(url, verify=False)  # Отключаем проверку сертификата SSL
            print(f"Ответ от SVD: {response.status_code} - {response.text}")  # Добавляем отладочное сообщение
            status_payment = False
            if response.status_code == 200:
                status_payment = True
            return status_payment
    except requests.exceptions.RequestException as e:
        print(f"Ошибка при отправке запроса в SVD: {e}")
        return False
    except Exception as e:
        print(f"Неизвестная ошибка: {e}")
        return False

# Миг сервис пополнить счет
def payment_mig(client: str, summ: int, comment: str, p_date: str) -> bool:
    params = {
        "command": "pay",
        "txn_id": get_date_time_for_id_payment(),
        "txn_date": get_date_time_for_id_payment() if not p_date else convert_date_to_id_format(p_date),
        "bank_code": "1c-mig",
        "account": str(client),
        "sum": summ,
        "comment": str(comment.replace(" ", "%20"))  # Экранируем пробелы в comment
    }
    # Формируем URL без кодирования comment
    url = f"https://10.101.2.4:9446/hydra/1c/main?command={params['command']}&txn_id={params['txn_id']}&txn_date={params['txn_date']}&bank_code={params['bank_code']}&account={params['account']}&sum={params['sum']}&comment={params['comment']}"
    print(f"URL для MIG: {url}")  # Добавляем отладочное сообщение

    try:
        with requests.Session() as session:
            response = session.get(url, verify=False)  # Отключаем проверку сертификата SSL
            print(f"Ответ от MIG: {response.status_code} - {response.text}")  # Добавляем отладочное сообщение
            status_payment = False
            if response.status_code == 200:
                status_payment = True
            return status_payment
    except requests.exceptions.RequestException as e:
        print(f"Ошибка при отправке запроса в MIG: {e}")
        return False
    except Exception as e:
        print(f"Неизвестная ошибка: {e}")
        return False

@app.route('/')
@ip_required
def index():
    return render_template('index.html')

@app.route('/static/dist/<path:path>')
@ip_required
def send_dist(path):
    return send_from_directory('static/dist', path)

@app.get('/api/check-oper-access')
@ip_required
def check_oper_access():
    id_oper = request.args.get('id_oper')
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) FROM admins_data WHERE id_operator = %s', (id_oper,))
    result = cur.fetchone()[0]
    cur.close()
    conn.close()
    if result > 0:
        return jsonify({"access": "granted"})
    else:
        return jsonify({"access": "denied"})

@app.get('/api/check-main-client')
@ip_required
def check_main_client():
    main_clients = ["PRO99999", "PRK99999", "MIG99999", "SVD99999"]
    main_client = request.args.get('main_client')
    
    if main_client in main_clients:
        return jsonify({"status": "yes"})
    else:
        return jsonify({"status": "no"})

@app.get('/api/get-data-operator')
@ip_required
def get_data_operator():
    oper_id = request.args.get('oper_id')
    url = f'http://10.101.2.100/api.php?key=vjyntdbltj&cat=operator&action=get&id={int(oper_id)}'
    data = requests.get(url=url)
    resp = data.json()
    return jsonify(resp)
    
@app.get('/api/get-history-payment-main-client')
@ip_required
def get_history_payment_main_client():
    main_client = request.args.get('main_client')
    date_from = '2000-02-01'
    date_to = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
    
    url_check_payment = f'http://194.247.191.135:9999/api/v1/getAccountHistory?abon_code={main_client}&date_from={date_from}&date_to={date_to}'
    b_token = 'ZmY0ZjFkZmQzMjA3M2IxM2Y3ZDYzOTlhMjY4OTA1Mjc6ODRmMjZiOGFiNWU4OTQ1NDgwZDUzNjQyODI0Zjg3MGE='
    headers = {
        'Authorization': f'Bearer {b_token}'
    }
    get_history = requests.get(url=url_check_payment, headers=headers)
    history = get_history.json()

    return jsonify(history)

@app.get('/api/hydra-delete-payment')
@ip_required
def delete_payment():
    id_doc = request.args.get('id_doc')
    response = requests.post('http://194.247.191.135:4320/api/delete-payment', json={'id_doc': id_doc})
    return jsonify(response.json())

@app.get('/api/hydra-add-payment')
@ip_required
def add_payment():
    org = request.args.get('org')
    client = request.args.get('client')
    summ = request.args.get('summ')
    comment = request.args.get('comment')
    p_day = request.args.get('date')
    
    # Убираем подстроку "(Платежная система)" из комментария, если она присутствует
    if "(Платежная система)" in comment:
        comment = comment.replace("(Платежная система)", "").strip()
    
    logging.debug(f"Параметры запроса: org={org}, client={client}, summ={summ}, comment={comment}, date={p_day}")
    
    if org == 'PRO':
        try_pay = payment_proxima(client, summ, comment, p_date=p_day)
    elif org == 'PRK':
        try_pay = payment_prk(client, summ, comment, p_date=p_day)
    elif org == 'MIG':
        try_pay = payment_mig(client, summ, comment, p_date=p_day)
    elif org == 'SVD':
        try_pay = payment_svd(client, summ, comment, p_date=p_day)
    else:
        logging.error("Компания не распознана")
        return jsonify({'error': 'company not recognized'})
    
    pay_status = 'bad'
    if try_pay:
        pay_status = 'ok'
    
    logging.debug(f"Статус платежа: {pay_status}")
    return jsonify({'payment_status': pay_status})

@app.get('/api/userside-get-id-by-login')
@ip_required
def userside_get_id_by_login():
    client = request.args.get('client')
    url = f'http://194.247.191.135:5541/get_user_side_id?login={client}'
    b_token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImhhY2siLCJwYXNzd29yZCI6InBsYW5ldCJ9.zrYvOCgMioWgYcNcxAzrHwp7pUyAe52-9YetkXdvcdU'
    headers = {
        'Authorization': f'Bearer {b_token}'
    }
    get_data = requests.get(url=url, headers=headers)
    resp_data = get_data.json()
    return jsonify({'userside_id': resp_data.get('user_id')})

@app.get('/api/userside-create-task')
@ip_required
def userside_create_task():
    client_id_userside = request.args.get('client_id_userside')
    url = f'http://10.101.2.100/api.php?key=vjyntdbltj&cat=task&work_typer=24&action=add&usercode={client_id_userside}'
    get_resp = requests.get(url=url)
    resp_data = get_resp.json()
    id_task = resp_data.get('Id')
    return jsonify({'task_id': id_task})

@app.route('/uploads/<filename>')
# @ip_required
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.post('/api/userside-add-file-in-task')
@ip_required
def userside_add_file_in_task():
    task_id = request.form.get('task_id')
    file = request.files.get('file')
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)
    api_url = "http://10.101.2.100/api.php"
    
    try:
        # Создаем URL для загруженного файла
        file_url = f"https://projects.proximanet.ru:4321/uploads/{file.filename}"

        # Отправляем запрос на добавление файла в задачу
        params = {
            'key': 'vjyntdbltj',
            'cat': 'attach',
            'action': 'add',
            'object_type': 'task',
            'object_id': task_id,
            'src': file_url
        }
        url_with_params = f"{api_url}?{requests.compat.urlencode(params)}"
        print(f"URL с параметрами: {url_with_params}")  # Отладочная информация
        api_response = requests.get(url_with_params)

        if api_response.status_code != 200:
            print(f"Ошибка при добавлении файла в задачу: {api_response.status_code} - {api_response.text}")
            return jsonify({'status_upload': 'bad', 'error': f'Ошибка при добавлении файла в задачу: {api_response.status_code} - {api_response.text}'}), 500

        os.remove(file_path)
        return jsonify({'status_upload': 'ok', 'api_response': api_response.text})
    except Exception as e:
        print(f"Ошибка при загрузке файла: {e}")
        return jsonify({'status_upload': 'bad', 'error': str(e)})

@app.get('/api/userside-add-comment-in-task')
@ip_required
def userside_add_comment_in_task():
    task_id = request.args.get('task_id')
    comment = request.args.get('comment')
    url = f'http://10.101.2.100/api.php?key=vjyntdbltj&cat=task&action=comment_add&id={task_id}&comment={comment}'
    get_resp = requests.get(url=url)
    status_add_comment = 'bad'
    if get_resp.status_code == 200:
        status_add_comment = 'ok'
        url = f'http://10.101.2.100/api.php?key=vjyntdbltj&cat=task&action=change_state&id={task_id}&state_id=2'
        requests.get(url=url)# закрываем заявку
    return jsonify({'status': status_add_comment})

@app.get('/api/userside-close-task')
@ip_required
def userside_close_task():
    task_id = request.args.get('task_id')
    url = f'http://10.101.2.100/api.php?key=vjyntdbltj&cat=task&action=change_state&id={task_id}&state_id=2'
    get_resp = requests.get(url=url)
    status_closed = 'bad'
    if get_resp.status_code == 200:
        status_closed = 'ok'
    return jsonify({'status': status_closed})

@app.get('/api/get-payment-info')
@ip_required
def get_payment_info():
    num_pay = request.args.get('num_pay')
    conn_params = {
        "dbname": "proxima1c",
        "user": "proxima",
        "password": "api",
        "host": "194.247.191.135",
        "port": "5433"
    }
    
    try:
        conn = psycopg2.connect(**conn_params)
        cur = conn.cursor()
        cur.execute('SELECT note, payeer_name FROM payments WHERE num_pay = %s', (num_pay,))
        result = cur.fetchone()
        cur.close()
        conn.close()
        
        if result:
            return jsonify({"note": result[0], "payeer_name": result[1]})
        else:
            return jsonify({"note": "Данных нет", "payeer_name": "Данных нет"})
    except Exception as e:
        logging.error(f"Ошибка при получении данных: {e}")
        return jsonify({"error": "Ошибка при получении данных"}), 500

# Отправка сообщений в телеграм канал
def send_data_to_telegram(data):
    # ID юзеров в телеге кому слать сообщения
    # 2029333793 - Я =)
    # 488235219 - Мельникова Я.
    id_telegram_users = ['2029333793', '488235219']
    # шлём данные в бота
    for id in id_telegram_users:
        requests.get(f'https://api.telegram.org/bot6752356598:AAEYRJDU5AnKhzcbKYJMWKnFl5MzuE9hVwo/sendMessage?chat_id={id}&text={data}')


@app.get('/api/telegram-send-message')
@ip_required
def telegram_send_message():
    message = request.args.get('message')
    send_data_to_telegram(data=message)
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    context = ssl.SSLContext(ssl.PROTOCOL_TLS)
    context.load_cert_chain('/etc/letsencrypt/live/projects.proximanet.ru/fullchain.pem', '/etc/letsencrypt/live/projects.proximanet.ru/privkey.pem')
    app.run(debug=True, host='projects.proximanet.ru', port=4321, ssl_context=context)